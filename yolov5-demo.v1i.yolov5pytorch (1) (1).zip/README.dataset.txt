# yolov5-demo > 2025-02-16 11:38am
https://universe.roboflow.com/cheemalapati-padmaja-fe0rz/yolov5-demo-ssgu5

Provided by a Roboflow user
License: CC BY 4.0

